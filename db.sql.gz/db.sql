-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arquivos`
--

DROP TABLE IF EXISTS `arquivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `arquivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `arquivo` varchar(255) NOT NULL,
  `extensao` varchar(50) NOT NULL,
  `checked` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arquivos`
--

LOCK TABLES `arquivos` WRITE;
/*!40000 ALTER TABLE `arquivos` DISABLE KEYS */;
INSERT INTO `arquivos` VALUES
(1,'Blue Sky Mine.mp3','mp3',1),
(2,'Another Brick In The Wall.mp3','mp3',1),
(3,'one.mp3','mp3',1),
(4,'Im_yours.mp3','mp3',1),
(5,'set_fire_to_the_rain.mp3','mp3',1),
(6,'love_in_an_elevator.mp3','mp3',1),
(7,'patience.mp3','mp3',1),
(8,'i_dont_wanna_miss_a_thing.mp3','mp3',1),
(9,'cryin.mp3','mp3',1),
(10,'amazing.mp3','mp3',1),
(11,'whats_going_on.mp3','mp3',1),
(12,'Baby Can I Hold You.mp3','mp3',1),
(13,'you_could_be_mine.mp3','mp3',1),
(14,'dont_cry.mp3','mp3',1),
(15,'boulevard_of_broken_songs.mp3','mp3',1),
(16,'i_do.mp3','mp3',1),
(17,'Assim sem coop.mp4','mp4',1),
(18,'Always.mp3','mp3',1),
(19,'sina.mp4','mp4',1),
(20,'dream_on.mp3','mp3',1),
(21,'listen_to_your_heart.mp3','mp3',1),
(22,'thank_you_for_loving Me.mp3','mp3',1),
(23,'everything_i_do_i_do_it_for_you.mp3','mp3',1),
(24,'november_rain.mp3','mp3',1),
(25,'breakaway.mp3','mp3',1),
(26,'heaven.mp3','mp3',1),
(27,'tears_in_heaven.mp3','mp3',1),
(28,'new aquarela.mp4','mp4',1),
(29,'walk_this_way.mp3','mp3',1),
(30,'spending_my_time.mp3','mp3',1),
(31,'gettin_over_you.mp3','mp3',1),
(32,'angel.mp3','mp3',1),
(33,'sunday_bloody_sunday.mp3','mp3',1),
(34,'crazy.mp3','mp3',1),
(35,'Welcome to the jungle.mp3','mp3',1),
(36,'when_you_love_someone.mp3','mp3',1),
(37,'knockin_on_heavens_door.mp3','mp3',1),
(38,'fly_away_from_here.mp3','mp3',1),
(39,'sweet_child_o_mine.mp3','mp3',1),
(40,'with_or_without_you.mp3','mp3',1);
/*!40000 ALTER TABLE `arquivos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-20 16:48:12
